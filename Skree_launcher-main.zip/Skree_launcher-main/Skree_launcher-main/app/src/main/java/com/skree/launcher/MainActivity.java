package com.skree.launcher;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.io.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import java.util.ArrayList;
import java.util.HashMap;
import android.widget.LinearLayout;
import androidx.recyclerview.widget.*;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import android.content.Intent;
import android.net.Uri;
import android.view.View;
import android.graphics.Typeface;
import com.gjiazhe.wavesidebar.*;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.DialogFragment;
import android.widget.TextClock;
import androidx.core.widget.NestedScrollView;
import com.skree.launcher.wierdo.*;

public class MainActivity extends AppCompatActivity {
	
	private FloatingActionButton _fab;
	private String g = "";
	private String fontName = "";
	private String typeace = "";
	
	private ArrayList<HashMap<String, Object>> getApplicationList = new ArrayList<>();
	
	private NestedScrollView base_scroll;
	private LinearLayout base;
	private RelativeLayout clock;
	private TextClock date_details;
	private TextClock aorp;
	private LinearLayout linear1;
	private TextClock time_details;
	private RecyclerView app_list;
	
	private Intent i = new Intent();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		_fab = findViewById(R.id._fab);
		
		base_scroll = findViewById(R.id.base_scroll);
		base = findViewById(R.id.base);
		clock = findViewById(R.id.clock);
		date_details = findViewById(R.id.date_details);
		aorp = findViewById(R.id.aorp);
		linear1 = findViewById(R.id.linear1);
		time_details = findViewById(R.id.time_details);
		app_list = findViewById(R.id.app_list);
		
		_fab.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), SearchActivity.class);
				i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(i);
			}
		});
	}
	
	private void initializeLogic() {
		app_list.setLayoutManager(new LinearLayoutManager(this));
		app_list.setAdapter(new App_listAdapter(_getApplicationList("app_name", "package_name")));
		_changeActivityFont("readex");
		base_scroll.smoothScrollTo(0,0);
	}
	
	
	@Override
	public void onBackPressed() {
		base_scroll.smoothScrollTo(0,0);
	}
	
	@Override
	public void onResume() {
		super.onResume();
		base_scroll.smoothScrollTo(0,0);
	}
	
	@Override
	public void onPause() {
		super.onPause();
		base_scroll.smoothScrollTo(0,0);
	}
	public void _setImageBitmap(final ImageView _imageview, final String _packagename) {
		new wierdo(this).setImageBitmap(_imageview,_packagename);
	}
	
	
	public void _openApplication(final String _packageName) {
		new wierdo(this).openApp(_packageName);
	}
	
	
	public ArrayList<HashMap<String, Object>> _getApplicationList(final String _app_name, final String _package_name) {
		return new wierdo(this).getApplicationList(_app_name,_package_name);
	}
	
	
	public void _changeActivityFont(final String _fontname) {
		fontName = "fonts/".concat(_fontname.concat(".ttf"));
		overrideFonts(this,getWindow().getDecorView()); 
	} 
	private void overrideFonts(final android.content.Context context, final View v) {
		
		try {
			Typeface 
			typeace = Typeface.createFromAsset(getAssets(), fontName);;
			if ((v instanceof ViewGroup)) {
				ViewGroup vg = (ViewGroup) v;
				for (int i = 0;
				i < vg.getChildCount();
				i++) {
					View child = vg.getChildAt(i);
					overrideFonts(context, child);
				}
			}
			else {
				if ((v instanceof TextView)) {
					((TextView) v).setTypeface(typeace);
				}
				else {
					if ((v instanceof EditText )) {
						((EditText) v).setTypeface(typeace);
					}
					else {
						if ((v instanceof Button)) {
							((Button) v).setTypeface(typeace);
						}
					}
				}
			}
		}
		catch(Exception e)
		
		{
			SketchwareUtil.showMessage(getApplicationContext(), "Error Loading Font");
		};
	}
	
	public class App_listAdapter extends RecyclerView.Adapter<App_listAdapter.ViewHolder> {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public App_listAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = (LayoutInflater) getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _v = _inflater.inflate(R.layout.applist, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final androidx.cardview.widget.CardView base_card = _view.findViewById(R.id.base_card);
			final LinearLayout base = _view.findViewById(R.id.base);
			final ImageView app_img = _view.findViewById(R.id.app_img);
			final TextView app_name = _view.findViewById(R.id.app_name);
			
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_view.setLayoutParams(_lp);
			app_name.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/readex.ttf"), 0);
			SketchwareUtil.sortListMap(_data, "app_name", false, true);
			app_name.setText(_data.get((int)_position).get("app_name").toString());
			_setImageBitmap(app_img, _data.get((int)_position).get("package_name").toString());
			base.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					_openApplication(_data.get((int)_position).get("package_name").toString());
				}
			});
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder {
			public ViewHolder(View v) {
				super(v);
			}
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}